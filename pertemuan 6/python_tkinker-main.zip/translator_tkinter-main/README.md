# translator_tkinter

# install googletrans
pip install googletrans==3.1.0a0

# Output
![image](https://github.com/freddywicaksono/translator_tkinter/blob/main/translator_tkinter.jpg)
