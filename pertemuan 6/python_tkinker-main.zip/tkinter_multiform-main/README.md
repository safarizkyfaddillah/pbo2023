# tkinter_multiform
![dashboard](https://github.com/freddywicaksono/tkinter_multiform/blob/main/sc.jpg)
